# MOBILE_HANDOFF_TEST_v1

## Purpose
Minimal dry-run of the permanent **Mobile Handoff Protocol**.

This package verifies that a Cloud Agent can:
1. produce a downloadable ZIP in `architecture/handoff/mobile_outbox/`;
2. commit + push it on the current feature branch / PR;
3. expose a GitHub download link usable from Android.

## Not a product change
No product / trading / MBG code was modified for this test.

## Package contents
- `README.md` — this file
- `TEST_PHONE_SYNC.txt` — phone→agent sync marker from the current branch
- `MANIFEST.sha256` — SHA-256 checksums of packaged files (except this zip)

## How to get the result on the PC
The ZIP exists in the cloud Git branch / PR, **not** automatically in `D:\genessis`.

```bash
git fetch origin
git checkout cursor/test-phone-sync-05bb
git pull
```

Then open:
`architecture/handoff/mobile_outbox/MOBILE_HANDOFF_TEST_v1.zip`

## Protocol (going forward)
After any task that requires Backend Architect + Market Architect review:

1. Finish the allowed task and required tests.
2. Build ZIP only after that.
3. Place ZIP under `architecture/handoff/mobile_outbox/`.
4. Name: `<STEP_OR_RFC>_<PURPOSE>_PACKAGE_v<N>.zip`
5. Include: README, source brief/contract, changed files or exact diff, test results, acceptance checklist, unresolved gaps, forbidden/not-done actions, commit SHA, branch, PR URL, next expected verdict.
6. Verify ZIP opens; list contents; compute SHA-256; check size; commit; push; update existing PR.
7. Reply with the MOBILE HANDOFF block (STATUS, ZIP_NAME, REPO_PATH, SIZE, SHA256, BRANCH, COMMIT, PR, DOWNLOAD, LOCAL_APPLY_COMMAND).

## Verdict for this test package
- **STATUS:** READY_FOR_MOBILE_DOWNLOAD
- **Next expected verdict:** ACK from owner that ZIP opens on Android and contents match this README
- **RFC-0003:** not in scope for this test; do not close RFC-0003 based on this package
