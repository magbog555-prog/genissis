# Source Task / Allowed Contract

## Task
PHASE II — RFC-0003 FINAL ACCEPTANCE EVIDENCE

## Objective
Do NOT modify implementation.
Do NOT modify Spec.
Do NOT modify RFC.
Generate the complete acceptance evidence package required to close RFC-0003.

## Claimed current status (from owner brief)
- RFC-0003: DUAL_ACCEPTED
- SPEC: ACCEPTED
- IMPLEMENTATION: COMPLETE
- CODE: COMPLETE

## Required deliverables
1. ORGAN_RUNTIME_ACCEPTANCE_REPORT.md
2. OrganEvaluationTerminalRecord samples (TIMEOUT, CANCELLED_BEFORE_START, OVERLOAD_REJECTED, FAILED)
3. Heartbeat evidence (ALIVE / LATE / LOST + lifecycle)
4. Legacy Adapter Alignment Report (Chart, DOM, Tape, Spread)
5. Capacity Smoke Report
6. Implementation Scope Diff (Producer, MW1, Brain, C7, Risk, Execution, UI untouched)
7. Implementation Commit Identity
8. Implementation Evidence Index

## Package name
RFC-0003_FINAL_ACCEPTANCE_EVIDENCE_PACKAGE_v1.zip

## Hard rules
NO CODE CHANGES / NO SPEC CHANGES / NO RFC CHANGES / NO NEW FEATURES — evidence only.
