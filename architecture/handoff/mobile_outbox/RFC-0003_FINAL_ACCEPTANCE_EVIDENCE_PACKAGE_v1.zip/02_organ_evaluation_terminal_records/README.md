# OrganEvaluationTerminalRecord samples

## Requirement
Provide **real** examples for:
- TIMEOUT
- CANCELLED_BEFORE_START
- OVERLOAD_REJECTED
- FAILED

Each record must demonstrate that terminal records are **NOT** observations.

## Result
**UNAVAILABLE — NO REAL SAMPLES.**

No Organ Runtime implementation, fixtures, or recorded terminal events exist in this Git clone.
Placeholder JSON files below document the gap. They are **not** runtime evidence and must not be treated as acceptance proof.
