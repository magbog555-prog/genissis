# Heartbeat evidence

## Required fields
organ_instance_id, heartbeat_seq, runtime_state, last_frame_seen, last_observation, queue_depth, last_error

## Required states
ALIVE, LATE, LOST — plus one lifecycle transition.

## Result
**UNAVAILABLE.** No organ heartbeat schema or samples in this clone.

Note: MBG connection heartbeats (`lastConnectionHeartbeatAt`, LAW-028) exist under MBG Observable Core and are **out of scope** for RFC-0003 Organ Runtime evidence (different contract).
