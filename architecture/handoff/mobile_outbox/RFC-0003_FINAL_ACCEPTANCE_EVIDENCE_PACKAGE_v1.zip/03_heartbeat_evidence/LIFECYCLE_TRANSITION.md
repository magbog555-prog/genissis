# Heartbeat lifecycle transition

**Status:** UNAVAILABLE

No ALIVE → LATE → LOST (or equivalent) organ heartbeat transition could be extracted from this clone.
