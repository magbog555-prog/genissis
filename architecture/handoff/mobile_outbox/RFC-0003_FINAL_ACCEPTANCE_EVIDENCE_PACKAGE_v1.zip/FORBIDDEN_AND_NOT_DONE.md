# Forbidden and Not Performed Actions

## Forbidden by task (honored)
- Modify implementation — **NOT DONE**
- Modify Spec — **NOT DONE**
- Modify RFC — **NOT DONE**
- Add new features / polish Runtime — **NOT DONE**
- Open RFC-0004 — **NOT DONE**
- Merge to `main` — **NOT DONE**
- Delete existing handoff packages — **NOT DONE**

## Explicitly refused
- Invent green pytest/smoke numbers
- Fabricate “real” terminal/heartbeat records
- Issue PASS / CLOSE for RFC-0003 without source evidence
