# Legacy Adapter Alignment Report

**Status:** `UNAVAILABLE`  
**Generated:** 2026-07-13T07:16:06Z

## Adapters required
| Adapter | Legacy timestamps | Frame ids | Adapter observation | Sample counts | Missing | Mismatch | Hash equality |
|---------|-------------------|-----------|---------------------|---------------|---------|----------|---------------|
| Chart | n/a | n/a | n/a | n/a | **ALL** | n/a | n/a |
| DOM | n/a | n/a | n/a | n/a | **ALL** | n/a | n/a |
| Tape | n/a | n/a | n/a | n/a | **ALL** | n/a | n/a |
| Spread | n/a | n/a | n/a | n/a | **ALL** | n/a | n/a |

## Finding
No Chart/DOM/Tape/Spread legacy adapter modules or alignment fixtures found.

Frontend adapters present in MBG source target (`mockAdapter.js`, `apiAdapter.js`) are **not** these market organs and were not used as substitute evidence.
