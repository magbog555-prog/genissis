# Capacity Smoke Report

**Status:** `NOT_RUN`  
**Synthetic mark:** N/A — no synthetic numbers invented for close evidence  
**Generated:** 2026-07-13T07:16:06Z

| Metric | Value |
|--------|-------|
| symbols | UNAVAILABLE |
| active organs | UNAVAILABLE |
| evaluation requests | UNAVAILABLE |
| queue depth | UNAVAILABLE |
| P50 | UNAVAILABLE |
| P95 | UNAVAILABLE |
| P99 | UNAVAILABLE |
| timeouts | UNAVAILABLE |
| overload rejects | UNAVAILABLE |
| stale drops | UNAVAILABLE |
| duration | UNAVAILABLE |
| memory | UNAVAILABLE |

## Reason
No capacity smoke harness or recorded organ-runtime capacity run exists in this clone.  
Task allows synthetic values **if clearly marked**; fabricating a green capacity profile without a harness would mislead RFC closure — therefore values remain UNAVAILABLE.
